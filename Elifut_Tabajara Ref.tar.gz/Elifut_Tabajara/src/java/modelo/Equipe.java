/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.ArrayList;
import persistencia.JogadorDAO;

/**
 *
 * @author anderson
 */
public class Equipe {

    private int codtime;
    private String nometime;
    private String cidade;
    private ArrayList<Jogador> vetJogadores;

    public Equipe() {
    }
    
    

    public Equipe(String nome) {
        this.nometime = nome;
    }

    public Equipe(int codtime, String nometime) {
        this.codtime = codtime;
        this.nometime = nometime;
    }

    public int getCodtime() {
        return codtime;
    }

    public ArrayList<Jogador> getVetJogadores() {
        return vetJogadores;
    }

    public void setVetJogadores(ArrayList<Jogador> vetJogadores) {
        this.vetJogadores = vetJogadores;
    }

    public void setCodtime(int codtime) {
        this.codtime = codtime;
    }

    public String getNometime() {
        return nometime;
    }

    public void setNometime(String nometime) {
        this.nometime = nometime;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

}
