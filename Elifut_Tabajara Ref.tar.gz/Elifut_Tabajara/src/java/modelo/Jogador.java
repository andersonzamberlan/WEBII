/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author anderson
 */
public class Jogador {

    private int codjog;
    private String nomejog;
    private String posicaojog;
    private Equipe equipe;

    public Equipe getEquipe() {
        return equipe;
    }

    public void setEquipe(Equipe equipe) {
        this.equipe = equipe;
    }
    
    

    public int getCodjog() {
        return codjog;
    }

    public void setCodjog(int codjog) {
        this.codjog = codjog;
    }

    public String getNomejog() {
        return nomejog;
    }

    public void setNomejog(String nomejog) {
        this.nomejog = nomejog;
    }

    public String getPosicaojog() {
        return posicaojog;
    }

    public void setPosicaojog(String posicaojog) {
        this.posicaojog = posicaojog;
    }

}
