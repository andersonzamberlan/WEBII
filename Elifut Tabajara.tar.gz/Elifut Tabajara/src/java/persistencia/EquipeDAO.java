/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Equipe;

/**
 *
 * @author anderson
 */
public class EquipeDAO {

    public boolean adicionar(Equipe equipe) throws SQLException {
        ConexaoPostgreSQL conexaoPostgreSQL = new ConexaoPostgreSQL();
        int resultado;
        try (Connection connection = conexaoPostgreSQL.getConnection()) {
            String sql = "INSERT INTO equipes(nometime, cidade) VALUES (?, ?);";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, equipe.getNometime());
            preparedStatement.setString(2, equipe.getCidade());
            resultado = preparedStatement.executeUpdate();
            preparedStatement.close();
        }
        return resultado == 1;

    }

    public ArrayList<Equipe> listar() throws SQLException {
        ArrayList<Equipe> vet = new ArrayList();
        String sql = "SELECT * FROM equipes";
        ConexaoPostgreSQL conexaoPostgreSQL = new ConexaoPostgreSQL();
        Connection connection = conexaoPostgreSQL.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet rs = preparedStatement.executeQuery();

        while (rs.next()) {
            Equipe equipe = new Equipe();

            equipe.setCodtime(rs.getInt("codtime"));
            equipe.setNometime(rs.getString("nometime"));
            equipe.setCidade(rs.getString("cidade"));


            vet.add(equipe);

        }
        preparedStatement.close();
        connection.close();

        return vet;
    }

    public Equipe obtertime(int id) throws SQLException {
        Equipe equipe = new Equipe();
        String sql = "SELECT * FROM equipes WHERE codtime = ?";
        ConexaoPostgreSQL conexaoPostgreSQL = new ConexaoPostgreSQL();
        Connection connection = conexaoPostgreSQL.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, id);
        ResultSet rs = preparedStatement.executeQuery();

        if (rs.next()) {

            equipe.setCodtime(rs.getInt("codtime"));
            equipe.setNometime(rs.getString("nometime"));
            equipe.setCidade(rs.getString("cidade"));

        }
        preparedStatement.close();
        connection.close();
        return equipe;

    }

    public boolean alterartime(Equipe equipe) throws SQLException {
        ConexaoPostgreSQL conexaoPostgreSQL = new ConexaoPostgreSQL();
        Connection connection = conexaoPostgreSQL.getConnection();
        String sql = "UPDATE equipes SET nometime = ?,  cidade = ? WHERE codtime = ?;";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, equipe.getNometime());
        preparedStatement.setString(2, equipe.getCidade());
        preparedStatement.setInt(3, equipe.getCodtime());
        int resultado = preparedStatement.executeUpdate();
        preparedStatement.close();
        connection.close();
        return resultado == 1;

    }

     public boolean excluirtime (int id) throws SQLException {
        ConexaoPostgreSQL conexaoPostgreSQL = new ConexaoPostgreSQL();
        Connection connection = conexaoPostgreSQL.getConnection();
        String sql = "DELETE FROM equipes WHERE codtime = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, id);
        int resultado = preparedStatement.executeUpdate();
        preparedStatement.close();
        connection.close();
        return resultado == 1;
    }
}
