/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Jogador;

/**
 *
 * @author anderson
 */
public class JogadorDAO {

     
    
    public boolean adicionar(Jogador jogador) throws SQLException{
        ConexaoPostgreSQL conexaoPostgreSQL = new ConexaoPostgreSQL();
        int resultado;
        try (Connection connection = conexaoPostgreSQL.getConnection()) {
            String sql = "INSERT INTO jogadores(nomejog, posicaojog,codtime) VALUES (?, ?,?);";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, jogador.getNomejog());
            preparedStatement.setString(2,jogador.getPosicaojog());
            preparedStatement.setInt(3, jogador.getCodtime());
            resultado = preparedStatement.executeUpdate();
            preparedStatement.close();
        }
        return resultado == 1;
        
    }
    
    public ArrayList<Jogador> listar() throws SQLException {
        ArrayList<Jogador> vet = new ArrayList();
        String sql = "SELECT * FROM jogadores WHERE codtime = 0 ;";
        ConexaoPostgreSQL conexaoPostgreSQL = new ConexaoPostgreSQL();
        Connection connection = conexaoPostgreSQL.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet rs = preparedStatement.executeQuery();
        
        
        while(rs.next()){
            Jogador jogador = new Jogador();
            
            jogador.setCodjog(rs.getInt("codjog"));
            jogador.setNomejog(rs.getString("nomejog"));
            jogador.setPosicaojog(rs.getString("posicaojog"));
           
          
            
            
            vet.add(jogador);
            
        }
        preparedStatement.close();
        connection.close();
        
        return vet;
    }
    
     public ArrayList<Jogador> listarcomEquipe() throws SQLException {
        ArrayList<Jogador> vet2 = new ArrayList();
        String sql = "SELECT codjog,nomejog,posicaojog,nometime FROM jogadores,equipes where jogadores.codtime =  equipes.codtime;";
        ConexaoPostgreSQL conexaoPostgreSQL = new ConexaoPostgreSQL();
        Connection connection = conexaoPostgreSQL.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet rs = preparedStatement.executeQuery();
        
        
        while(rs.next()){
            Jogador jogador = new Jogador();
            
            jogador.setCodjog(rs.getInt("codjog"));
            jogador.setNomejog(rs.getString("nomejog"));
            jogador.setPosicaojog(rs.getString("posicaojog"));
            jogador.setNometime(rs.getString("nometime"));
          
            
            
            vet2.add(jogador);
            
        }
        preparedStatement.close();
        connection.close();
        
        return vet2;
    }
    
    public boolean alterarjog(Jogador jogador) throws SQLException{
        ConexaoPostgreSQL conexaoPostgreSQL = new ConexaoPostgreSQL();
        Connection connection = conexaoPostgreSQL.getConnection();
        String sql = "UPDATE jogadores SET nomejog = ?,  posicaojog = ?,codtime = ? WHERE codjog = ?;";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, jogador.getNomejog());
        preparedStatement.setString(2, jogador.getPosicaojog());
        preparedStatement.setInt(3, jogador.getCodtime());
        preparedStatement.setInt(4, jogador.getCodjog());
        int resultado = preparedStatement.executeUpdate();
        preparedStatement.close();
        connection.close();
        return resultado == 1;
        
    }
    
    public Jogador obterjog(int id) throws SQLException{
        Jogador jogador = new Jogador();
        String sql = "SELECT * FROM jogadores WHERE codjog = ?";
        ConexaoPostgreSQL conexaoPostgreSQL = new ConexaoPostgreSQL();
        Connection connection = conexaoPostgreSQL.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, id);
        ResultSet rs = preparedStatement.executeQuery();
               
        if (rs.next()){
            
            jogador.setCodjog(rs.getInt("codjog"));
            jogador.setNomejog(rs.getString("nomejog"));
            jogador.setPosicaojog(rs.getString("posicaojog"));
               
        }
        preparedStatement.close();
        connection.close();
        return jogador;
        
    }
    public boolean excluirjog (int id) throws SQLException {
        ConexaoPostgreSQL conexaoPostgreSQL = new ConexaoPostgreSQL();
        Connection connection = conexaoPostgreSQL.getConnection();
        String sql = "DELETE FROM jogadores WHERE codjog = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, id);
        int resultado = preparedStatement.executeUpdate();
        preparedStatement.close();
        connection.close();
        return resultado == 1;
    }
    
     public ArrayList<Jogador> equipe(int id) throws SQLException {
        ArrayList<Jogador> vet3 = new ArrayList();
        String sql = "SELECT jogadores.codjog,jogadores.nomejog,jogadores.posicaojog,equipes.nometime FROM jogadores "
                + "inner join equipes on jogadores.codtime =  equipes.codtime WHERE equipes.codtime = ?;";
        ConexaoPostgreSQL conexaoPostgreSQL = new ConexaoPostgreSQL();
        Connection connection = conexaoPostgreSQL.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, id);
        ResultSet rs = preparedStatement.executeQuery();
        
        
        while(rs.next()){
            Jogador jogador = new Jogador();
            
            jogador.setCodjog(rs.getInt("codjog"));
            jogador.setNomejog(rs.getString("nomejog"));
            jogador.setPosicaojog(rs.getString("posicaojog"));
            jogador.setNometime(rs.getString("nometime"));
          
            
            
            vet3.add(jogador);
            
        }
        preparedStatement.close();
        connection.close();
        
        return vet3;
    }
}
