/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.ArrayList;
import persistencia.JogadorDAO;

/**
 *
 * @author anderson
 */
public class Equipe {
    
    int codtime;
    String nometime;
    String cidade;
//     ArrayList<Jogador> vet = new JogadorDAO();

    public int getCodtime() {
        return codtime;
    }

    public void setCodtime(int codtime) {
        this.codtime = codtime;
    }

    public String getNometime() {
        return nometime;
    }

    public void setNometime(String nometime) {
        this.nometime = nometime;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }
    
    
}
