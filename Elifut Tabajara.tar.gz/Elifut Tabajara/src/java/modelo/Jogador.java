/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author anderson
 */
public class Jogador {
    
    int codjog;
    String nomejog;
    String posicaojog;
    int codtime;
    String nometime;

    public String getNometime() {
        return nometime;
    }

    public void setNometime(String nometime) {
        this.nometime = nometime;
    }
    

    public int getCodjog() {
        return codjog;
    }

    public void setCodjog(int codjog) {
        this.codjog = codjog;
    }

    public String getNomejog() {
        return nomejog;
    }

    public void setNomejog(String nomejog) {
        this.nomejog = nomejog;
    }

    public String getPosicaojog() {
        return posicaojog;
    }

    public void setPosicaojog(String posicaojog) {
        this.posicaojog = posicaojog;
    }

    public int getCodtime() {
        return codtime;
    }

    public void setCodtime(int codtime) {
        this.codtime = codtime;
    }
    
}
